﻿namespace Control_view3.BussinesLayer
{
    public enum EnumTPrestamo
    {
            Personal=1,
            Automovil,
            Hipotecario
    }
}

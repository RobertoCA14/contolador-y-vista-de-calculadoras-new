﻿namespace Control_view3.Models
{
    public class C_Prestamo
    {
        public double Monto { get; set; }
        public double Tipo { get; set; }
        public int Meses { get; set; }
        public double Resultado { get; set; }
    }
}

﻿namespace Control_view3.Models
{
    public class SignZodiaco
    {
        public int Dia { get; set; }
        public int Mes { get; set; }
        
    }
}

﻿namespace Control_view3.Models
{
    public class CambioDivisas
    {
        public double Moneda1 { get; set; }
        public double Resultado { get; set; }
        public double Moneda2 { get; set; }
       
    }
}
